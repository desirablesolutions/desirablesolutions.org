import displacementImg1 from './1.jpg';
import displacementImg2 from './2.jpg';
import displacementImg3 from './3.jpg';
import displacementImg4 from './4.png';
import displacementImg5 from './5.png';
import displacementImg6 from './6.jpg';
import displacementImg7 from './7.jpg';
import displacementImg8 from './8.jpg';
import displacementImg9 from './9.jpg';
import displacementImg10 from './10.jpg';
import displacementImg11 from './11.jpg';
import displacementImg12 from './12.jpg';
import displacementImg13 from './13.jpg';
import displacementImg14 from './14.jpg';
import displacementImg15 from './15.jpg';
import displacementImg16 from './16.jpg';

export const displacementImages = [
  displacementImg1,
  displacementImg2,
  displacementImg3,
  displacementImg4,
  displacementImg5,
  displacementImg6,
  displacementImg7,
  displacementImg8,
  displacementImg9,
  displacementImg10,
  displacementImg11,
  displacementImg12,
  displacementImg13,
  displacementImg14,
  displacementImg15,
  displacementImg16,
];
